def add(*args):
    total = 0
    for i in args:
        total += i
        return total
    
c = add(1,2,3,4,5,6,7,8,9)
print(c)
