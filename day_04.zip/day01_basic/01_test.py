print('''a = 'he'
b = a.upper()
print(a)
print(b)
''')
print('''/n''')
print('아\n니')